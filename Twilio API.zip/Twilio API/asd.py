# Download the helper library from https://www.twilio.com/docs/python/install
from twilio.rest import Client
import serial
import time
ser = serial.Serial('COM3', 9600) # Change the com port


# Your Account Sid and Auth Token from twilio.com/console
account_sid = 'AC301c2f067836c36870508690b1c5e5ef'
auth_token = '5c08aa2f87cfbbb6f8050bdda771e69c'
client = Client(account_sid, authtoken)


while True:
    while ser.inWaiting():
        temp = ser.readline().decode()
        messageTosend="Alert!!! The door is open."  # ändra til vårt meddelande
        message = client.messages.create(
                              body=messageTosend,
                              from='whatsapp:+14155238886', # Twilio WhatsApp Numner
                              to='whatsapp:+46700912337'  # Write your WhatsApp Number here
                          )
        time.sleep(10)

print(message.sid)